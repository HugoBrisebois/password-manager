from .main import PasswordManagerApp

if __name__ == "__main__":
    app = PasswordManagerApp()
    app.mainloop()
