# Password-Manager
this a simple application NOT meant for commercial use and ONLY for fun.
this application will allow you to manage your passwords without the headache of searching through a disorganized password manager like Bitwarden.
this app will sort your passwords in alphabetical order with a similar GUI to Microsoft Authenticator.

## Features
- exporting passwords to an .csv(Excel) file
- adding and deleting passwords

## Usage
- modifying and recreational usage ONLY
- fun and learn purpose only

## Requirments

- python 1.13
- tkinter 
- ttk

install requirments

'''sh
pip install tkinter
'''

run the app 

'''sh
python main.py
'''
