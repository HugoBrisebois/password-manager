from .main import PasswordManagerApp

if __name__ == "__main__":
    app = PasswordManagerApp()
    app.mainloop()

def main():
    app = PasswordManagerApp()
    app.mainloop()

if __name__ == "__main__":
    main()
