# This file marks the generator_password directory as a Python package.
